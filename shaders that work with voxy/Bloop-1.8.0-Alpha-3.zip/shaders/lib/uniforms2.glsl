/*----------------------------------------------------------------------------------------------
        _____                                                                    _____
        ( ___ )                                                                  ( ___ )
        |   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|   |
        |   | ██╗   ██╗███╗   ██╗██╗███████╗ ██████╗ ██████╗ ███╗   ███╗███████╗ |   |
        |   | ██║   ██║████╗  ██║██║██╔════╝██╔═══██╗██╔══██╗████╗ ████║██╔════╝ |   |
        |   | ██║   ██║██╔██╗ ██║██║█████╗  ██║   ██║██████╔╝██╔████╔██║███████╗ |   |
        |   | ██║   ██║██║╚██╗██║██║██╔══╝  ██║   ██║██╔══██╗██║╚██╔╝██║╚════██║ |   |
        |   | ╚██████╔╝██║ ╚████║██║██║     ╚██████╔╝██║  ██║██║ ╚═╝ ██║███████║ |   |
        |   |  ╚═════╝ ╚═╝  ╚═══╝╚═╝╚═╝      ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝ |   |
        |___|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|___|
        (_____)                              (thanks to isuewo and SpacEagle17)  (_____)

---------------------------------------------------------------------------------------------*/
uniform bool isRightHanded = true;
uniform int blockEntityId;

uniform int entityId;
uniform int frameCounter;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;
uniform int isEyeInWater;
uniform int moonPhase;
uniform int worldTime;
uniform int worldDay;
uniform int bedrockLevel;
uniform int hideGUI;
uniform int renderStage;
uniform float aspectRatio;
uniform float blindness;

uniform float darknessFactor;
uniform float darknessLightFactor;
uniform float maxBlindnessDarkness;
uniform float eyeAltitude;
uniform float frameTime;
uniform float centerDepthSmooth;
#ifdef FROZEN_TIME
float frameTimeCounter = 10;
#else
uniform float frameTimeCounter;
#endif
uniform float far;
uniform float near;
uniform float nightVision;
uniform float rainStrength;
uniform float screenBrightness;
uniform float viewHeight;
uniform float viewWidth;
uniform float wetness;
uniform float sunAngle;

uniform ivec2 atlasSize;
uniform ivec2 eyeBrightness;
uniform ivec2 eyeBrightnessSmooth;

uniform vec3 cameraPosition;
uniform vec3 fogColor;
uniform vec3 previousCameraPosition;
uniform vec3 skyColor;
uniform vec3 eyePosition;
uniform vec3 shadowLightPosition;
uniform vec3 playerLookVector;
uniform vec3 upPosition;

uniform vec4 entityColor;
// uniform vec4 lightningBoltPosition = vec4(0);

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowProjectionInverse;
uniform mat4 shadowModelViewProjection;
uniform mat4 modelViewMatrix;
uniform mat4 modelViewMatrixInverse;
uniform mat4 projectionMatrix;
uniform mat4 projectionMatrixInverse;
uniform mat3 normalMatrix;
uniform mat4 textureMatrix;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D colortex8;
uniform sampler2D colortex9;
uniform sampler2D colortex10;
uniform sampler2D colortex11;

uniform sampler2D colortex12;

uniform sampler2D colortex13;

uniform sampler3D colortex15;
uniform sampler2D depthtex0;

uniform sampler2D depthtex1;

uniform sampler2D depthtex2;
uniform sampler2D gaux1;
uniform sampler2D gaux2;
uniform sampler2D gaux3;
uniform sampler2D gaux4;
uniform sampler2D normals;

uniform sampler2D noisetex;
uniform sampler2D specular;
uniform sampler2D tex;
uniform sampler2D texture;

uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;

uniform sampler2DShadow shadow;
uniform sampler2DShadow shadowtex1;

uniform sampler2D shadowtex0;

#ifdef DISTANT_HORIZONS
uniform int dhRenderDistance;
uniform float dhNearPlane;
uniform float dhFarPlane;
uniform mat4 dhProjection;
uniform mat4 dhProjectionInverse;
uniform mat4 dhPreviousProjection;

uniform sampler2D dhDepthTex;
uniform sampler2D dhDepthTex0;
uniform sampler2D dhDepthTex1;
#endif

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

#ifdef LPV_ENABLED
uniform usampler1D texBlockData;
uniform sampler3D texLpv1;
uniform sampler3D texLpv2;
uniform int currentRenderedItemId;
#endif
#if defined IS_IRIS
uniform float cloudHeight;
uniform int heightLimit;
uniform float cloudTime;

#else
float cloudTime = frameTimeCounter;

float cloudHeight = 192;
int heightLimit = 320;
#endif

uniform vec2 redPrimary;
uniform vec2 bluePrimary;
uniform vec2 greenPrimary;
uniform vec2 whitePoint;
uniform float maxLuminance;      // absolute
uniform float maxFrameLuminance; // absolute
uniform float minLuminance;      // absolute

/*-----------------------------------------------------------------------------
  ___ _   _ ___ _____ ___  __  __   _   _ _  _ ___ ___ ___  ___ __  __ ___
 / __| | | / __|_   _/ _ \|  \/  | | | | | \| |_ _| __/ _ \| _ \  \/  / __|
| (__| |_| \__ \ | || (_) | |\/| | | |_| | .` || || _| (_) |   / |\/| \__ \
 \___|\___/|___/ |_| \___/|_|  |_|  \___/|_|\_|___|_| \___/|_|_\_|  |_|___/

-----------------------------------------------------------------------------*/

#ifdef VOXY
uniform sampler2D colortex19;
uniform sampler2D vxDepthTexOpaque;
uniform sampler2D vxDepthTexTrans;
uniform mat4 vxProj;
uniform mat4 vxProjInv;
uniform mat4 vxProjPrev;
uniform mat4 vxViewProjInv;
uniform mat4 vxViewProj;

uniform int vxRenderDistance;

float lod_near = near;
float lod_far = float(16 * vxRenderDistance);

mat4 lod_gbufferProjection = mat4(
    vec4(gbufferProjection[0][0], 0.0, 0.0, 0.0),
    vec4(0.0, gbufferProjection[1][1], 0.0, 0.0),
    vec4(
        gbufferProjection[2][0],
        gbufferProjection[2][1],
        (lod_far + lod_near) / (lod_near - lod_far),
        -1.0),
    vec4(
        0.0,
        0.0,
        (2.0 * lod_far * lod_near) / (lod_near - lod_far),
        0.0));

mat4 lod_gbufferProjectionInverse = mat4(
    vec4(gbufferProjectionInverse[0][0], 0.0, 0.0, 0.0),
    vec4(0.0, gbufferProjectionInverse[1][1], 0.0, 0.0),
    vec4(
        0.0,
        0.0,
        0.0,
        -(lod_far - lod_near) / (2.0 * lod_far * lod_near)),
    vec4(
        gbufferProjectionInverse[3][0],
        gbufferProjectionInverse[3][1],
        -1.0,
        (lod_far + lod_near) / (2.0 * lod_far * lod_near)));

// #define depthtex0 vxDepthTexOpaque
// #define depthtex1 vxDepthTexTrans

    #define near lod_near
    #define far lod_far
    #define gbProjection_proxy lod_gbufferProjection
    #define gbProjectionInverse_proxy lod_gbufferProjectionInverse
#else
    #define gbProjection_proxy gbufferProjection
    #define gbProjectionInverse_proxy gbufferProjectionInverse

#endif

uniform int framemod8;

uniform float velocity;
uniform float nearorg;
uniform float farorg;

uniform float sunsetBlend;
uniform float nightblend5Inv;
uniform float nightblend5;
uniform float rainStrengthInv;
uniform float shadowblend;

uniform float sunElevation;
uniform float sunpow;
uniform float lightRadiance;
uniform float nightblendShadows;
uniform float SunsetMult;
uniform float hdrMult;
uniform float hdrMulttorch;

uniform vec2 viewResolution;
uniform vec2 texelSize;
uniform vec3 sunVec;
uniform vec3 sunPosWorld;
uniform vec3 moonPosWorld;

#ifdef OVERWORLD
uniform vec3 sunLight;
uniform vec3 atmosphereUp;

#elif defined END
vec3 sunLight = clamp(vec3(0.01) * pow(dot(vec3(0.01), vec3(0.299, 0.587, 0.114)), -0.75) * 0.65, 0.0, 1.0) * 0.5;
vec3 atmosphereUp = clamp(vec3(0.01) * pow(dot(vec3(0.01), vec3(0.299, 0.587, 0.114)), -0.75) * 0.65, 0.0, 1.0) * 0.5;
#else
vec3 sunLight = clamp(fogColor * pow(dot(fogColor, vec3(0.299, 0.587, 0.114)), -0.75) * 0.65, 0.0, 1.0) * 0.5;
vec3 atmosphereUp = clamp(fogColor * pow(dot(fogColor, vec3(0.299, 0.587, 0.114)), -0.75) * 0.65, 0.0, 1.0) * 0.5;

#endif

uniform vec3 lightPos;
uniform vec3 shadowPosWorld;

/*-----------------------------------------------------------------------------
MODS
-----------------------------------------------------------------------------*/
