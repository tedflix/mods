

#ifdef TAA

const vec2 offsets[8] = vec2[8](
    vec2(0.125, -0.375), vec2(-0.125, 0.375),
    vec2(0.625, 0.125), vec2(-0.375, -0.625),
    vec2(-0.625, 0.625), vec2(-0.875, -0.125),
    vec2(0.375, 0.875), vec2(0.875, -0.875));

#else
const vec2 offsets[8] = vec2[8](vec2(0.0, -0.0), vec2(-0.0, 0.0), vec2(0.0, 0.0), vec2(-0.0, -0.0), vec2(-0.0, 0.0),
                                vec2(-0.0, -0.0), vec2(0.0, 0.0), vec2(0.0, -0.0));

#endif
vec4 taaFunc(vec4 position)
{
#ifdef TAA
    position.xy += offsets[framemod8] * position.w * texelSize;
#endif
    return position;
}
