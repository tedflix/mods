#version 140 compatibility
#include "/includes/main.glsl"
#define OVERWORLD

//#include "/program/gbuffers/discard.fsh"
#include "/program/gbuffers/dh/gbuffers_clouds.fsh"
