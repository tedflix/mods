#version 140 compatibility
#define OVERWORLD
#include "/includes/main.glsl"
#define ENTITY

#define COMPLEX_NORMALS
#include "/program/gbuffers/translucent/gbuffers_simple_translucent_hand.vsh"

