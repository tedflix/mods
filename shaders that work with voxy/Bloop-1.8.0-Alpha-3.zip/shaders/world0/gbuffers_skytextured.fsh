#version 150 compatibility
#extension GL_ARB_shader_bit_encoding : enable
#define OVERWORLD
#include "/includes/main.glsl"

#include "/program/gbuffers/solid/gbuffers_sun.fsh"

