#version 140 compatibility
#define OVERWORLD
#include "/includes/main.glsl"

#define COMPLEX_NORMALS

#ifdef PBR
#include "/program/gbuffers/solid/gbuffers_complex.vsh"
#else
#include "/program/gbuffers/solid/gbuffers_med.vsh"
#endif


