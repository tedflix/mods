#version 430 compatibility
#define NO_PROJECT

#define RENDER_SETUP

#include "/includes/main.glsl"

#include "/program/lpv/setup.csh"
