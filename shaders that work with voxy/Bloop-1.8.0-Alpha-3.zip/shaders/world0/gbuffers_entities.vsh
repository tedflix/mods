#version 140 compatibility
#define OVERWORLD
#include "/includes/main.glsl"

#define COMPLEX_NORMALS
#define ENTITY
#if MC_VERSION < 12111
#ifdef PBR
    #ifdef LAB_PBR
        #include "/program/gbuffers/solid/gbuffers_complex.vsh"
    #else
        #include "/program/gbuffers/solid/gbuffers_complex_entity.vsh"

    #endif
#else
    #include "/program/gbuffers/solid/gbuffers_med.vsh"
#endif

#else

#include "/program/gbuffers/translucent/gbuffers_entities.vsh"
#endif
