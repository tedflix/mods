#version 140 compatibility
#define OVERWORLD
#define WATER
#include "/includes/main.glsl"

#include "/program/gbuffers/translucent/gbuffers_water.fsh"

