#version 140 compatibility
#extension GL_ARB_shader_texture_lod : enable
#extension GL_ARB_shader_bit_encoding : enable
#define OVERWORLD
#include "/includes/main.glsl"
#if MC_VERSION < 12111
#define ENTITY
#ifdef PBR
    #ifdef LAB_PBR
        #include "/program/gbuffers/solid/gbuffers_complex.fsh"
    #else
        #include "/program/gbuffers/solid/gbuffers_complex_entity.fsh"

    #endif
#else
    #include "/program/gbuffers/solid/gbuffers_med.fsh"
#endif
#else
#define ENTITY
        #include "/program/gbuffers/translucent/gbuffers_entities.fsh"
#endif
