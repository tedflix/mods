#version 140 compatibility
#define OVERWORLD
#define altnoise
const bool colortex7MipmapEnabled = true;

#include "/includes/main.glsl"

#include "/program/skyfog.fsh"
