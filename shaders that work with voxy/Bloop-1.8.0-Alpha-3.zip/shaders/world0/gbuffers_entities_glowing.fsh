#version 140 compatibility
#extension GL_ARB_shader_bit_encoding : enable
#define OVERWORLD
#define ENTITY
#include "/includes/main.glsl"

#include "/program/gbuffers/solid/gbuffers_med.fsh"

