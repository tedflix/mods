#version 140 compatibility
#extension GL_ARB_shader_bit_encoding : enable

#define OVERWORLD
#include "/includes/main.glsl"

#define COMPLEX_NORMALS
#define HAND

#if SSR_QUALITY > 1
#include "/program/gbuffers/solid/gbuffers_complex.fsh"
#else
#include "/program/gbuffers/solid/gbuffers_med.fsh"
#endif


