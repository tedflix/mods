#version 430 compatibility
#define NO_PROJECT

#include "/includes/main.glsl"

#include "/program/lpv/shadowcomp.csh"
