#version 140 compatibility
#extension GL_ARB_shader_texture_lod : enable
#extension GL_ARB_shader_bit_encoding : enable
#define OVERWORLD
#include "/includes/main.glsl"

#define ENTITY
#ifdef PBR
    #ifdef LAB_PBR
        #include "/program/gbuffers/translucent/gbuffers_entities.fsh"
    #else
        #include "/program/gbuffers/translucent/gbuffers_entities.fsh"

    #endif
#else
    #include "/program/gbuffers/translucent/gbuffers_entities.fsh"
#endif
