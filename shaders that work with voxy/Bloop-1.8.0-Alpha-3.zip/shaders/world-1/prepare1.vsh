#version 140 compatibility
#define NETHER
#include "/includes/main.glsl"

#include "/program/waternormals.vsh"

