#version 140 compatibility
#define OVERWORLD
#include "/includes/main.glsl"

#define COMPLEX_NORMALS
#define ENTITY

#define ENTITY
#ifdef PBR
    #ifdef LAB_PBR
#include "/program/gbuffers/translucent/gbuffers_entities.vsh"
    #else
#include "/program/gbuffers/translucent/gbuffers_entities.vsh"

    #endif
#else
#include "/program/gbuffers/translucent/gbuffers_entities.vsh"
#endif
