#version 140 compatibility
#extension GL_ARB_texture_gather : enable
#define NETHER

#include "/includes/main.glsl"

#include "/program/dof.fsh"

