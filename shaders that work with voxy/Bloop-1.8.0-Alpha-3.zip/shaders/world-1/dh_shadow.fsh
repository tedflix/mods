#version 140 compatibility
#include "/includes/main.glsl"

#extension GL_EXT_gpu_shader4 : enable

varying vec4 lmtexcoord;
varying vec4 color;
varying vec3 viewVector;






void main()
{
    /* DRAWBUFFERS:0*/

    // vec4 color = vec4(toLinear(texture(tex, lmtexcoord.xy).rgb * color.rgb) * lmtexcoord.w +   toLinear(texture(tex,
    // lmtexcoord.xy).rgb * color.rgb) * lmtexcoord.z,  texture(tex, lmtexcoord.xy).a);
    vec4 color = texture(tex, lmtexcoord.xy) * color;
    if (length(viewVector) < 0.8 * far)
    {
        discard;
    }

    gl_FragData[0] = vec4(color);
    // discard;
    //  gl_FragData[0].a = float(color.a >= noise_standard(gl_FragCoord.xy)*0.5);
}
