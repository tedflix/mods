#version 140 compatibility
#define NETHER
#define altnoise
#include "/includes/main.glsl"

#include "/program/clouds.fsh"
