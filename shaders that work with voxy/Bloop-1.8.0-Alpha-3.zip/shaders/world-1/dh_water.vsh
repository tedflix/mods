#version 140 compatibility
#define NETHER
#include "/includes/main.glsl"

#include "/program/gbuffers/dh/gbuffers_dh_water.vsh"

