#version 140 compatibility
#define NETHER
#include "/includes/main.glsl"

#include "/program/gbuffers/solid/gbuffers_med_discard.vsh"
