#version 140 compatibility
#define NETHER
#include "/includes/main.glsl"

#ifdef PBR

#include "/program/gbuffers/solid/gbuffers_complex.vsh"
#else
#include "/program/gbuffers/solid/gbuffers_med.vsh"
#endif
