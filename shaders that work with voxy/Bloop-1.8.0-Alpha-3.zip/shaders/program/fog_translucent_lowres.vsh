
flat varying vec3 zMults;



varying vec2 texcoord;







void main() {

    texcoord = gl_MultiTexCoord0.xy;
	zMults = vec3(1.0/(far * near),far+near,far-near);

    gl_Position = ftransform();
	gl_Position.xy = (gl_Position.xy*0.5+0.5)*(0.01+VL_RENDER_RESOLUTION)*2.0-1.0;

}
