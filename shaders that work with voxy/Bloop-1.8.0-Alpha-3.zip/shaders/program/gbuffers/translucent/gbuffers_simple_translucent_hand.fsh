

varying vec4 color;
varying float NdotL;
varying vec3 normal2;
varying vec3 p3;

flat varying vec3 torch;
varying vec2 texcoord;

/* DRAWBUFFERS:1*/

vec3 GGX1(
    vec3 N,
    vec3 V,
    vec3 L,
    float roughness,
    vec3 F0)
{
    // half‐vector + dot products
    vec3 H = normalize(V + L);
    float NdotV = clamp(dot(N, V), 0.0, 1.0);
    float NdotL = clamp(dot(N, L), 0.0, 1.0);
    float NdotH = clamp(dot(N, H), 0.0, 1.0);
    float VdotH = clamp(dot(V, H), 0.0, 1.0);

    // sun angular radius: blend between dry & wet limits, then clamp
    float minSun = 0.005; // ~0.57°
    float maxSun = 0.200; // ~11.5°
    float sunAngRad = mix(minSun, maxSun, clamp(rainStrength, 0.0, 1.0));
    sunAngRad = clamp(sunAngRad, minSun, maxSun);

    // combined variance = roughness² + sunAngRad², with a floor
    float rou = clamp(roughness, 0.0, 1.0);
    float rou2 = rou * rou + sunAngRad * sunAngRad;
    rou2 = max(rou2, 1e-6);
    float a = sqrt(rou2);
    float a2 = a * a;

    // GGX NDF
    float denomD = NdotH * NdotH * (a2 - 1.0) + 1.0;
    denomD = max(denomD, 1e-6);
    float D = a2 / (3.1415 * denomD * denomD);

    // Smith‐Schlick geometry
    float k = (a + 1.0) * (a + 1.0) * 0.125;
    float Gv = NdotV / (NdotV * (1.0 - k) + k);
    float Gl = NdotL / (NdotL * (1.0 - k) + k);
    float G = Gv * Gl;

    // Schlick Fresnel
    vec3 F = mix(F0, vec3(1.0), pow(1.0 - VdotH, 5.0));

    // keep denominators safe
    float denom = max(4.0 * NdotV * NdotL, 1e-6);

    // final specular, modulated by N·L
    return D * G * F * (NdotL / denom);
}

#define HALF_ANGLE 0.05 // radians
#define TILT_ANGLE 1.5  // radians

vec3 GGX2(
    vec3 N,
    vec3 V,
    vec3 sunDir,
    vec3 F0)
{
    vec3 outval = GGX1(
        N,
        V,
        lightPos,
        0.01,
        vec3(0.1));

    return outval;
}

void main()
{

    vec4 color = texture(texture, texcoord.xy) * color;
    color.a = pow(color.a, 0.75);
    float diffuseSun = mix(0.01, NdotL, min(eyeBrightnessSmooth.y / 240.0, 1.0));

    color.rgb = toLinear(color.rgb) * (sunLight * diffuseSun + (luma(atmosphereUp) * 2.0) + torch);


    gl_FragData[0] = color;
}
