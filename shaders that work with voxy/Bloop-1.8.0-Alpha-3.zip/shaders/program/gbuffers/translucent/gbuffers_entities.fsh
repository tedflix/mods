

#define SIMPLEFOG
#define WATERSTAGE

varying mat3 tbnMatrix;
varying vec4 color;
flat varying float iswater;
varying vec4 lmtexcoord;
varying vec3 torch;
varying vec3 viewVector;
varying vec3 p3;
varying vec3 normal0;
varying vec3 normal1;
flat varying vec4 labvalue;

#include "/lib/sky_function.glsl"
#include "/lib/light.glsl"

vec2 tapLocation(int sampleNumber, int nb, float nbRot, float jitter, float distort)
{
    float alpha = (sampleNumber + jitter) / nb;
    float angle = jitter * TWO_PI + alpha * nbRot * TWO_PI;

    float sin_v, cos_v;

    sin_v = sin(angle);
    cos_v = cos(angle);

    return vec2(cos_v, sin_v) * sqrt(alpha);
}

const vec2 shadowOffsets[6] = vec2[6](vec2(0.5303, 0.5303), vec2(-0.6250, -0.0000), vec2(0.3536, -0.3536),
                                      vec2(-0.0000, 0.3750), vec2(-0.1768, -0.1768), vec2(0.1250, 0.0000));

#define viewMAD(m, v) (mat3(m) * (v) + (m)[3].xyz)

#define diagonal3(m) vec3((m)[0].x, (m)[1].y, m[2].z)
#define projMAD(m, v) (diagonal3(m) * (v) + (m)[3].xyz)

#include "/lib/water/waterfuncs2.glsl"

#ifdef WATER_PBR
    #if SSR_QUALITY == 0
        #include "/lib/water/ssr_normal.glsl"
    #elif SSR_QUALITY == 1
        #include "/lib/water/ssr_extra_low.glsl"

    #elif SSR_QUALITY == 2
        #include "/lib/water/ssr_low.glsl"
    #else
        #include "/lib/water/ssr_hq.glsl"

    #endif
#else
    #include "/lib/water/ssr_normal.glsl"
#endif

float GetBorderFogMixFactorCylinder(in vec3 eyePlayerPos, in float far, bool isWater)
{

    float mixval = 0.75;

    if (isWater)
        mixval = 0.33;
    float eyeDist = length(eyePlayerPos.xz);
    float borderFogFactor = smoothstep(far * mixval, far, eyeDist);

    return borderFogFactor;
}

vec4 getSpecularProperties(vec2 tcoord)
{
    float reflectance = labvalue.x;
    float smoothness = labvalue.y;
    float sss = labvalue.z;
    float emissives = 0;
#ifdef LAB_PBR

    // vec4 specularTex = texture2DLod(specular, tcoord, 0);
    vec4 specularTex = texture(specular, tcoord);

    smoothness = specularTex.x;
    sss = specularTex.z;
    reflectance = specularTex.y;
    emissives = specularTex.w;

#endif
    return vec4(sss, emissives, reflectance, smoothness);
}

////
float phaseg(float x, float g)
{
    float gg = g * g;
    return (gg * -0.25 + 0.25) * pow(-2.0 * (g * x) + (gg + 1.0), -1.5) / PI;
}

#include "/lib/fog/fognoloop.glsl"

/*RENDERTARGETS: 1*/

void main()
{

    // --- Initial Setup ---
    vec2 texcoord = lmtexcoord.xy;

    // --- Previous Frame Mask ---

    vec4 materialProps = getSpecularProperties(texcoord);
    vec4 outcolor;

    // --- Normals Initialization ---
    vec3 normal = normal1;
    vec3 normalWorld = normal0;
    vec3 normalTex = vec3(0.0);

#ifdef LAB_PBR
    normalTex = texture(normals, texcoord).rgb;
    normal = normalize(tbnMatrix * (normalTex * 2.0 - 1.0));
    normalWorld = worldToView(normal);
#endif

    // --- Texture and Albedo Processing ---
    vec4 albedo = texture2D(texture, texcoord);
    albedo.rgb = toLinear(albedo.rgb * color.rgb);

    outcolor = albedo;

    // --- Lighting Calculation ---
    float diffuseSun = max(dot(normal, lightPos), 0.0) * lmtexcoord.w;
    float shading = 1.0;

#ifdef OVERWORLD
    if (diffuseSun > 0.0)
    {
        float noise = R2_dither(gl_FragCoord.xy);

        vec3 ProjShadowPos = mat3(shadowModelView) * p3 + shadowModelView[3].xyz;
        ProjShadowPos = diagonal3(shadowProjection) * ProjShadowPos + shadowProjection[3].xyz;

        float distortFactor = calcDistort(ProjShadowPos.xy);
        ProjShadowPos.xy *= distortFactor;

        if (all(lessThan(abs(ProjShadowPos.xy), (vec2(1.0, 1.0) - 1.5 / shadowMapResolution))) &&
            abs(ProjShadowPos.z) < 6)
        {
            float threshMulMult = mix(2048, 4096, float(eyeAltitude > 400));
            float threshMulMult2 = mix(threshMulMult, 8192, float(eyeAltitude > 500));
            float threshMul = max(threshMulMult2 / shadowMapResolution * shadowDistance / 100.0, 0.95);
            float distortThresh = clamp(sqrt(1.0 - diffuseSun * diffuseSun) / diffuseSun, 0.0, 0.25) / distortFactor;
            float diffthresh = distortThresh / 6000.0 * threshMul;

            ProjShadowPos = ProjShadowPos * vec3(0.5, 0.5, 0.5 / 6.0) + 0.5;

            shading = 0.0;
            float rdMul = 4.0 / shadowMapResolution;
            for (int i = 0; i < 9; i++)
            {
                vec2 offsetS = tapLocation(i, 9, 2.0, noise, 0.0);
                float weight = 1.0 + (i + noise) * rdMul / 9.0 * shadowMapResolution;
                vec3 shadowCoordWeighted = vec3(ProjShadowPos + vec3(rdMul * offsetS, -diffthresh * weight));
                float shadow0 = texture(shadowtex1, shadowCoordWeighted);
    #ifdef COLORED_SHADOWS
                float shadow1 = texture(shadow, shadowCoordWeighted);
                float transparentshadow = distance(shadow1, shadow0);
                vec4 shadowcolor = texture(shadowcolor0, shadowCoordWeighted.xy);
                if (transparentshadow > 0)
                {
                    shading += clamp(shadow1 + clamp((1 - shadowcolor.a), 0.0, 1.0), 0.0, 1.0) / 9.0;
                }
                else
                {
                    shading += shadow1 / 9.0;
                }
    #else
                shading += shadow0 / 9.0;
    #endif
            }
        }
        shading = mix(0.0, shading, shadowblend);
        diffuseSun = min(shading, diffuseSun) * lmtexcoord.w;
    }
#endif

    diffuseSun = diffuseSun * shadowblend * (-0.9 * rainStrength + 1.0);
    vec3 ambient = calcAmbientLight(normal, lmtexcoord.zw, atmosphereUp, diffuseSun, torch);

    outcolor.rgb += (materialProps.y * 8.0 * outcolor.rgb * outcolor.rgb);
    ambient *= color.a;

    vec3 transmission = ambient * outcolor.rgb;
    outcolor.rgb = transmission;

    // outcolor = reflections(lmtexcoord.w, normal, viewVector, materialProps, outcolor, diffuseSun, albedo.rgb,  outcolor.a);

    // outcolor = vec4(vec3(diffuseSun), outcolor.a);
    gl_FragData[0] = clamp(outcolor, 0, 1000);
}
