varying vec4 color;
varying vec2 lmtexcoord;

#ifdef SIMPLE
    #ifdef LITEMATICA
    /* DRAWBUFFERS:01*/
    #else
    /* DRAWBUFFERS:0*/
    #endif
#else
/* DRAWBUFFERS:0*/
#endif

void main()
{

    vec4 albedo = texture(texture, lmtexcoord);
    albedo.rgb = toLinear(albedo.rgb * color.rgb);
#ifdef SIMPLE
    albedo.a *= color.a * 2.0;

#if SELECTOR_COLOR == 0
    // black (no override)
    // albedo.rgb = albedo.rgb;
#elif SELECTOR_COLOR == 1
    // red
    albedo.rgb = vec3(1.0, 0.0, 0.0);
#elif SELECTOR_COLOR == 2
    // green
    albedo.rgb = vec3(0.0, 1.0, 0.0);
#elif SELECTOR_COLOR == 3
    // blue
    albedo.rgb = vec3(0.0, 0.0, 1.0);
#elif SELECTOR_COLOR == 4
    // yellow
    albedo.rgb = vec3(1.0, 1.0, 0.0);
#elif SELECTOR_COLOR == 5
    // pink
    albedo.rgb = vec3(1.0, 0.0, 1.0);
#elif SELECTOR_COLOR == 6
    // purple
    albedo.rgb = vec3(0.5, 0.0, 0.5);
#elif SELECTOR_COLOR == 7
    // orange
    albedo.rgb = vec3(1.0, 0.5, 0.0);
#elif SELECTOR_COLOR == 8
    // white
    albedo.rgb = vec3(1.0, 1.0, 1.0);
#elif SELECTOR_COLOR == 9
    // grey
    albedo.rgb = vec3(0.5, 0.5, 0.5);
#endif

#endif

    // discard;
    gl_FragData[0] = albedo;
}