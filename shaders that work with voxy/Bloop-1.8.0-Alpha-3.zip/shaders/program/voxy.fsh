

#define waterfog
varying vec2 texcoord;

void main()
{

    /* RENDERTARGETS: 19 */

    float z = texture(depthtex0, texcoord).x;

    float z0DH = texture(vxDepthTexOpaque, texcoord).x;
    vec3 DH = texture(colortex10, texcoord).rgb;
    vec3 sky = texture(colortex8, texcoord).rgb;
    float depth1 = z;
    float depth = z0DH;

    vec3 A = toScreenSpace_og(vec3(texcoord, z));
    vec3 B = toScreenSpaceDH(vec3(texcoord, z0DH));
    vec3 p3 = toWorldSpace(A);

    float eyeDist = max(length(p3.xz), abs(p3.y)) / far;

    bool check2 = (eyeDist < (1 / far) * (farorg + 64));


    if (check2)
    {
        depth = z;
    }

    vec3 fragpos = toScreenSpace(vec3(texcoord, z));

 
    float dist = length(p3);
    float fadeDist = 32.0;

    vec3 color = texture(colortex0, texcoord.xy).rgb;
    float blend = smoothstep(far - fadeDist, far, dist);

    color.rgb = mix(color, DH, blend);

    gl_FragData[0].rgb = (vec3(depth) / 1) * 1;
}
