#version 140 compatibility
#define END
#define WATER

#include "/includes/main.glsl"

#include "/program/gbuffers/translucent/gbuffers_water.fsh"

