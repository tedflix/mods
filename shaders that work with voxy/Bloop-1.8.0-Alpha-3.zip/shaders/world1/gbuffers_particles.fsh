#version 140 compatibility
#define END
#include "/includes/main.glsl"

#include "/program/gbuffers/translucent/gbuffers_simple_translucent.fsh"

