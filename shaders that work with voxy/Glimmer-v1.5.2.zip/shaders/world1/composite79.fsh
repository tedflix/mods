#include "/lib/version.glsl"

#define fsh
#define WORLD_THE_END

#include "/program/c89_temporalFilter.glsl"
