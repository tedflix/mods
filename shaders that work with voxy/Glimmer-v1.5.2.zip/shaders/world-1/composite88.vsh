#include "/lib/version.glsl"

#define vsh
#define WORLD_THE_NETHER

#define TILE_INDEX 0
#include "/program/bloomUpsample.glsl"
