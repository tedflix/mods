#include "/lib/version.glsl"

#define vsh
#define WORLD_THE_NETHER

#include "/program/c90_FXAA.glsl"
