#include "/lib/version.glsl"

#define vsh
#define WORLD_OVERWORLD

#include "/program/clrwl_shadow.glsl"
