#version 400 compatibility

#define STAGE_FRAGMENT
#define WORLD_END

#include "/programs/composite/fog_write.glsl"
